<!-- This README file is going to be the one displayed on the Grafana.com website for your plugin -->

# OpenObserve

OpenObserve

# License

OpenObserve commercial license. Please contact hello@openobserve.ai for more information.
